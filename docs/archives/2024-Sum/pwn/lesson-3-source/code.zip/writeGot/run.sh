gcc ./wg.c -z lazy -no-pie -fno-stack-protector -o wg
