#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include <string.h>


char *aBinSh = "/bin/sh";
int rdi(){
    __asm__ (
        "pop %rdi;" 
        "ret" 
    );
}

int main() {
    char a[10];
    size_t addr;
    size_t data;
    setvbuf(stdin, 0,2,0);
    setvbuf(stdout, 0,2,0);
    setvbuf(stderr, 0,2,0);
    
    printf("System addr : %llx\n", &system);
    printf("Where :");
    scanf("%llx",&addr);
    printf("Write: ");
    scanf("%llx", &data);
    *(size_t *)addr = data;

    puts("/bin/sh");
    return 0;
}