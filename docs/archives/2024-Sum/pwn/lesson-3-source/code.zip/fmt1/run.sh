gcc ./fmt1.c -z lazy -no-pie -fno-stack-protector -o fmt1

