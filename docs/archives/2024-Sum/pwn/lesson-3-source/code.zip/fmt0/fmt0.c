#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include <string.h>

int key = 0x811;
int main() {
    char a[16];
    setvbuf(stdin, 0,2,0);
    setvbuf(stdout, 0,2,0);
    setvbuf(stderr, 0,2,0);
    
    puts("Input: ");
    read(0,a,0x1000);
    printf(a);
    if (key==2) {
        puts("Get shell!");
        system("/bin/sh");
    }
    return 0;
}