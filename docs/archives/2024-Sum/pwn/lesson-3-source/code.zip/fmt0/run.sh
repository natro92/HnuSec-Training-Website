gcc ./fmt0.c -z lazy -no-pie -fno-stack-protector -o fmt0
