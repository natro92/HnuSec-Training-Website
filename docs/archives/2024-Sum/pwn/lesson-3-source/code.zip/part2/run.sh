gcc ./part2.c -z lazy -no-pie -fno-stack-protector -o part2
