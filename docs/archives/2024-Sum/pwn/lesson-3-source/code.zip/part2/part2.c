#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include <string.h>

char *aBinSh = "/bin/sh";
int rdi(){
    __asm__ (
        "pop %rdi;" 
        "ret" 
    );
}
int backdoor() {
    system("ping");
}
int main() {
    char a[10];
    setvbuf(stdin, 0,2,0);
    setvbuf(stdout, 0,2,0);
    setvbuf(stderr, 0,2,0);
    
    puts("Input: ");
    read(0,a,0x1000);
    return 0;
}