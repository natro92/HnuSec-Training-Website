#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include <string.h>


int rdi(){
    __asm__ (
        "pop %rdi;" 
        "ret" 
    );
}

int main() {
    char a[10];
    setvbuf(stdin, 0,2,0);
    setvbuf(stdout, 0,2,0);
    setvbuf(stderr, 0,2,0);
    
    puts("Input: ");
    read(0,a,0x1000);
    return 0;
}