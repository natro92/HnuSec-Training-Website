#!/bin/sh
gcc -Wl,-rpath="/glibc-all-in-one/2.27-3ubuntu1.6_amd64/",-dynamic-linker="/glibc-all-in-one/2.27-3ubuntu1.6_amd64/ld-linux-x86-64.so.2" ./ret2libc3.c -z lazy -no-pie -fno-stack-protector -o ret2libc3
