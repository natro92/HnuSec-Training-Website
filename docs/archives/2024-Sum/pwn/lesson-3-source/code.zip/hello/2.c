#include<stdio.h>
int main(){
    puts("hello world");
    puts("hello");
    return 0;
}